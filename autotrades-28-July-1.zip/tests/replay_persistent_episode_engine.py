#!/usr/bin/env python3
"""Replay one complete symbol-day through Persistent Episode V1.3.

The program is report-only.  It always starts each symbol at the first stored
snapshot, processes all snapshots chronologically and carries episode state in
memory.  It refuses to run unless the configured trades database name matches
``--allowed-database`` (default: backtest).
"""
from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from datetime import date, datetime, time
import json
import logging
import os
from pathlib import Path
import sys
import traceback
from typing import Any, Dict, Iterable, List, Optional, Sequence

from sqlalchemy.engine import make_url

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import AppConfig
from configs.auction_engine_config import AUCTION_ENGINE_CONFIG
from logconfig import setup_logging
from schemas.snapshot import SnapshotSchema
from services.auction_engine.engine import AuctionEngine
from services.auction_engine.episode_engine import (
    PersistentEpisodeEngine,
    build_episode_observation,
)
from utils.json_utils import sanitize_json

logger = logging.getLogger(__name__)

DEFAULT_EXCLUDED_SYMBOLS = ("NIFTY 50", "NIFTY BANK")


def _args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Replay full symbol-days through Persistent Episode V1.3."
    )
    parser.add_argument("--date", required=True, help="Trading day YYYY-MM-DD")
    parser.add_argument(
        "--symbols",
        default="",
        help="Optional comma-separated symbol filter; empty means all symbols",
    )
    parser.add_argument(
        "--exclude-symbols",
        default=",".join(DEFAULT_EXCLUDED_SYMBOLS),
        help="Comma-separated symbols excluded before replay",
    )
    parser.add_argument("--allowed-database", default="backtest")
    parser.add_argument("--report-dir", default="reports")
    parser.add_argument("--batch-size", type=int, default=500)
    parser.add_argument("--log-file")
    return parser.parse_args(argv)


def _symbol_list(raw: str) -> List[str]:
    return sorted({item.strip().upper() for item in raw.split(",") if item.strip()})


def _database_name() -> str:
    uri = AppConfig.SQLALCHEMY_BINDS["trades"]
    parsed = make_url(uri)
    if parsed.database is None:
        raise ValueError("Configured trades database URI has no database name")
    return parsed.database


def _preflight(*, allowed_database: str) -> str:
    database_name = _database_name()
    expected = str(allowed_database).strip()
    if not expected:
        raise ValueError("--allowed-database must be non-empty")
    if database_name != expected:
        raise RuntimeError(
            "Persistent Episode replay refused database connection: "
            f"configured={database_name!r}, allowed={expected!r}"
        )
    if not AUCTION_ENGINE_CONFIG.episode.enabled:
        raise RuntimeError("Persistent Episode V1.3 is disabled in configuration")
    if not AUCTION_ENGINE_CONFIG.episode.projection_only:
        raise RuntimeError("Persistent Episode V1.3 must remain projection-only")
    return database_name


def _load_snapshots(
    *,
    trading_day: date,
    symbols: List[str],
    excluded: List[str],
    batch_size: int,
) -> List[SnapshotSchema]:
    output: List[SnapshotSchema] = []
    after_time: Optional[datetime] = None
    after_symbol = ""
    while True:
        batch = SnapshotSchema.fetch_day_replay_batch(
            trading_day=trading_day,
            after_time=after_time,
            after_symbol=after_symbol,
            symbols=symbols if symbols else None,
            limit=max(1, int(batch_size)),
        )
        if not batch:
            break
        for snapshot in batch:
            if snapshot.symbol.strip().upper() not in excluded:
                output.append(snapshot)
        last = batch[-1]
        after_time = last.snapshot_time.replace(tzinfo=None)
        after_symbol = last.symbol
        if len(batch) < max(1, int(batch_size)):
            break
    return output


def _group_symbol_days(
    snapshots: Iterable[SnapshotSchema],
) -> Dict[str, List[SnapshotSchema]]:
    grouped: Dict[str, List[SnapshotSchema]] = defaultdict(list)
    for snapshot in snapshots:
        grouped[snapshot.symbol.strip().upper()].append(snapshot)
    for symbol in grouped:
        grouped[symbol].sort(key=lambda item: item.snapshot_time)
    return dict(grouped)


def _validate_symbol_sequence(
    *,
    symbol: str,
    snapshots: List[SnapshotSchema],
    trading_day: date,
) -> None:
    if not snapshots:
        raise ValueError(f"No snapshots loaded for {symbol}")
    expected_first = datetime.combine(
        trading_day,
        time.fromisoformat(AUCTION_ENGINE_CONFIG.engine.earliest_evaluation_time),
    )
    first = snapshots[0].snapshot_time.replace(tzinfo=None)
    if first != expected_first:
        raise ValueError(
            f"{symbol} first snapshot is {first}, expected {expected_first}"
        )

    interval_seconds = AUCTION_ENGINE_CONFIG.engine.snapshot_interval_minutes * 60.0
    previous: Optional[datetime] = None
    seen: set[datetime] = set()
    for snapshot in snapshots:
        current = snapshot.snapshot_time.replace(tzinfo=None)
        if snapshot.snapshot_time.date() != trading_day:
            raise ValueError(
                f"{symbol} snapshot {snapshot.snapshot_time} is outside {trading_day}"
            )
        if current in seen:
            raise ValueError(f"{symbol} duplicate snapshot time {current}")
        seen.add(current)
        if previous is not None:
            if current <= previous:
                raise ValueError(
                    f"{symbol} snapshots are not strictly increasing: "
                    f"{current} <= {previous}"
                )
            gap_seconds = (current - previous).total_seconds()
            if abs(gap_seconds - interval_seconds) > 1e-6:
                raise ValueError(
                    f"{symbol} snapshot gap is {gap_seconds / 60.0:.3f} minutes "
                    f"between {previous} and {current}; expected "
                    f"{AUCTION_ENGINE_CONFIG.engine.snapshot_interval_minutes:.3f}"
                )
        previous = current


def _write_csv(path: Path, rows: Iterable[Dict[str, Any]]) -> None:
    data = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not data:
        path.write_text("", encoding="utf-8")
        return
    fields = sorted({key for row in data for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(data)


def _timeline_row(result, episode) -> Dict[str, Any]:
    candidate_families = [item.family.value for item in result.candidates]
    candidate_ids = [item.candidate_id for item in result.candidates]
    blocked = {item.value for item in episode.blocked_setup_families}
    blocked_candidate_ids = [
        item.candidate_id for item in result.candidates if item.family.value in blocked
    ]
    return sanitize_json({
        "symbol": result.symbol,
        "snapshot_time": result.snapshot_time,
        "close": result.evidence.close,
        "legacy_auction_previous": result.auction_state.previous_state.value,
        "legacy_auction_current": result.auction_state.current_state.value,
        "legacy_candidate_count": len(result.candidates),
        "legacy_candidate_families": "|".join(candidate_families),
        "legacy_candidate_ids": "|".join(candidate_ids),
        "legacy_candidates_blocked_by_episode_count": len(blocked_candidate_ids),
        "legacy_candidates_blocked_by_episode_ids": "|".join(blocked_candidate_ids),
        "legacy_local_action": result.local_decision.action.value,
        "directional_episode_id": episode.directional.episode_id,
        "directional_previous_state": episode.directional.previous_state.value,
        "directional_current_state": episode.directional.current_state.value,
        "directional_direction": episode.directional.direction.value,
        "directional_origin_source": episode.directional.origin_source.value,
        "directional_parent_episode_id": episode.directional.parent_episode_id,
        "directional_origin_event_id": episode.directional.origin_event_id,
        "directional_started_at": episode.directional.started_at,
        "directional_state_started_at": episode.directional.state_started_at,
        "directional_state_age_bars": episode.directional.state_age_bars,
        "directional_origin_price": episode.directional.origin_price,
        "directional_extreme_price": episode.directional.extreme_price,
        "directional_extreme_time": episode.directional.extreme_time,
        "directional_protection_level": episode.directional.protection_level,
        "directional_protection_source": episode.directional.protection_source,
        "directional_reversal_confirmation_level": (
            episode.directional.reversal_confirmation_level
        ),
        "directional_reversal_confirmation_source": (
            episode.directional.reversal_confirmation_source
        ),
        "directional_reversal_confirmation_level_time": (
            episode.directional.reversal_confirmation_level_time
        ),
        "directional_first_adverse_bar_time": (
            episode.directional.first_adverse_bar_time
        ),
        "directional_first_adverse_bar_level": (
            episode.directional.first_adverse_bar_level
        ),
        "directional_first_adverse_bar_close": (
            episode.directional.first_adverse_bar_close
        ),
        "directional_rejection_seen": episode.directional.rejection_seen,
        "directional_continuation_failure_seen": (
            episode.directional.continuation_failure_seen
        ),
        "directional_continuation_failure_time": (
            episode.directional.continuation_failure_time
        ),
        "directional_reversal_confirmation_breach_closes": (
            episode.directional.reversal_confirmation_breach_closes
        ),
        "directional_reversal_leg_progress_bars": (
            episode.directional.reversal_leg_progress_bars
        ),
        "directional_reversal_leg_failure_closes": (
            episode.directional.reversal_leg_failure_closes
        ),
        "directional_reversal_leg_progress_atr": (
            episode.directional.reversal_leg_progress_atr
        ),
        "directional_reason_codes": "|".join(episode.directional.reason_codes),
        "balance_episode_id": episode.balance.episode_id,
        "balance_previous_state": episode.balance.previous_state.value,
        "balance_current_state": episode.balance.current_state.value,
        "balance_started_at": episode.balance.started_at,
        "balance_state_started_at": episode.balance.state_started_at,
        "balance_state_age_bars": episode.balance.state_age_bars,
        "balance_range_id": episode.balance.range_id,
        "balance_candidate_low": episode.balance.candidate_low,
        "balance_candidate_high": episode.balance.candidate_high,
        "balance_source_range_ids": "|".join(episode.balance.source_range_ids),
        "balance_candidate_merge_count": episode.balance.candidate_merge_count,
        "balance_candidate_bar_expansion_count": (
            episode.balance.candidate_bar_expansion_count
        ),
        "balance_candidate_last_valid_at": episode.balance.candidate_last_valid_at,
        "balance_forming_invalid_bars": episode.balance.forming_invalid_bars,
        "balance_frozen_low": episode.balance.frozen_low,
        "balance_frozen_high": episode.balance.frozen_high,
        "balance_containment_bars": episode.balance.containment_bars,
        "balance_forming_bars_observed": episode.balance.forming_bars_observed,
        "balance_marginal_excursion_bars": episode.balance.marginal_excursion_bars,
        "balance_meaningful_escape_bars": episode.balance.meaningful_escape_bars,
        "balance_containment_ratio": episode.balance.containment_ratio,
        "balance_escape_direction": episode.balance.escape_direction.value,
        "balance_outside_close_count": episode.balance.outside_close_count,
        "balance_reentry_close_count": episode.balance.reentry_close_count,
        "balance_reason_codes": "|".join(episode.balance.reason_codes),
        "episode_event_types": "|".join(
            item.event_type.value for item in episode.events
        ),
        "episode_event_ids": "|".join(item.event_id for item in episode.events),
        "structural_event_families": "|".join(
            item.value for item in episode.structural_event_families
        ),
        "permitted_setup_families": "|".join(
            item.value for item in episode.permitted_setup_families
        ),
        "blocked_setup_families": "|".join(
            item.value for item in episode.blocked_setup_families
        ),
    })


def _transition_rows(episode) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for event in episode.events:
        rows.append(sanitize_json({
            "symbol": event.symbol,
            "trading_day": event.trading_day,
            "event_time": event.event_time,
            "event_id": event.event_id,
            "event_type": event.event_type.value,
            "episode_id": event.episode_id,
            "direction": event.direction.value,
            "reason_codes": "|".join(event.reason_codes),
            "event_data": json.dumps(event.data, sort_keys=True, default=str),
        }))
    return rows


def run(args: argparse.Namespace) -> Dict[str, Any]:
    trading_day = date.fromisoformat(args.date)
    symbols = _symbol_list(args.symbols)
    excluded = _symbol_list(args.exclude_symbols)
    database_name = _preflight(allowed_database=args.allowed_database)
    snapshots = _load_snapshots(
        trading_day=trading_day,
        symbols=symbols,
        excluded=excluded,
        batch_size=args.batch_size,
    )
    grouped = _group_symbol_days(snapshots)
    if symbols:
        missing = sorted(set(symbols).difference(grouped))
        if missing:
            raise ValueError(f"No snapshots found for requested symbols: {missing}")

    timeline_rows: List[Dict[str, Any]] = []
    transition_rows: List[Dict[str, Any]] = []
    error_rows: List[Dict[str, Any]] = []
    event_counts: Counter[str] = Counter()
    directional_state_counts: Counter[str] = Counter()
    balance_state_counts: Counter[str] = Counter()
    directional_origin_counts: Counter[str] = Counter()
    directional_reason_counts: Counter[str] = Counter()
    balance_reason_counts: Counter[str] = Counter()
    symbols_completed = 0

    for symbol in sorted(grouped):
        symbol_snapshots = grouped[symbol]
        try:
            _validate_symbol_sequence(
                symbol=symbol,
                snapshots=symbol_snapshots,
                trading_day=trading_day,
            )
            auction_engine = AuctionEngine(AUCTION_ENGINE_CONFIG)
            episode_engine = PersistentEpisodeEngine(AUCTION_ENGINE_CONFIG)
            for snapshot in symbol_snapshots:
                result = auction_engine.evaluate_snapshot(
                    snapshot,
                    equity_ref=symbol,
                )
                observation = build_episode_observation(result)
                episode = episode_engine.advance(observation)
                timeline_rows.append(_timeline_row(result, episode))
                transition_rows.extend(_transition_rows(episode))
                event_counts.update(item.event_type.value for item in episode.events)
                directional_state_counts[episode.directional.current_state.value] += 1
                balance_state_counts[episode.balance.current_state.value] += 1
                directional_origin_counts[episode.directional.origin_source.value] += 1
                directional_reason_counts.update(episode.directional.reason_codes)
                balance_reason_counts.update(episode.balance.reason_codes)
            symbols_completed += 1
        except Exception as exc:
            logger.exception(
                "persistent_episode_symbol_failed symbol=%s trading_day=%s",
                symbol,
                trading_day,
            )
            error_rows.append({
                "symbol": symbol,
                "trading_day": trading_day.isoformat(),
                "snapshot_count": len(symbol_snapshots),
                "error_type": type(exc).__name__,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            })
            continue

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = f"persistent_episode_v1_3_{trading_day.isoformat()}_{stamp}"
    report_dir = Path(args.report_dir)
    timeline_path = report_dir / f"{prefix}_timeline.csv"
    transitions_path = report_dir / f"{prefix}_transitions.csv"
    errors_path = report_dir / f"{prefix}_errors.csv"
    summary_path = report_dir / f"{prefix}_summary.json"
    _write_csv(timeline_path, timeline_rows)
    _write_csv(transitions_path, transition_rows)
    _write_csv(errors_path, error_rows)

    summary = sanitize_json({
        "program": "replay_persistent_episode_engine.py",
        "version": AUCTION_ENGINE_CONFIG.episode.config_version,
        "projection_only": AUCTION_ENGINE_CONFIG.episode.projection_only,
        "database_name": database_name,
        "database_writes": False,
        "trading_day": trading_day,
        "requested_symbols": symbols,
        "excluded_symbols": excluded,
        "snapshots_loaded": len(snapshots),
        "symbols_loaded": len(grouped),
        "symbols_completed": symbols_completed,
        "symbols_failed": len(error_rows),
        "timeline_rows": len(timeline_rows),
        "transition_events": len(transition_rows),
        "event_counts": dict(sorted(event_counts.items())),
        "directional_state_snapshot_counts": dict(
            sorted(directional_state_counts.items())
        ),
        "balance_state_snapshot_counts": dict(sorted(balance_state_counts.items())),
        "directional_origin_snapshot_counts": dict(
            sorted(directional_origin_counts.items())
        ),
        "directional_reason_counts": dict(sorted(directional_reason_counts.items())),
        "balance_reason_counts": dict(sorted(balance_reason_counts.items())),
        "config": AUCTION_ENGINE_CONFIG.episode.model_dump(mode="json"),
        "output_files": {
            "timeline": str(timeline_path),
            "transitions": str(transitions_path),
            "errors": str(errors_path),
            "summary": str(summary_path),
        },
    })
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(
        json.dumps(summary, indent=2, sort_keys=True, default=str),
        encoding="utf-8",
    )
    return summary


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _args(argv)
    setup_logging(log_file=args.log_file)
    summary = run(args)
    print(json.dumps(summary, indent=2, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
