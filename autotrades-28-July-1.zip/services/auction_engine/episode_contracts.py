"""Strict contracts for the persistent Auction episode controller.

The first implementation is intentionally replay-oriented.  It processes one
symbol-day from the first completed snapshot and carries state forward in
memory.  It does not create signals, targets, stops, trades or database rows.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, Optional, Tuple

from pydantic import Field, model_validator

from services.auction_engine.contracts import (
    AuctionStateName,
    ContractModel,
    DirectionalBias,
    SetupFamily,
    StringEnum,
)


class DirectionalEpisodeState(StringEnum):
    NONE = "NONE"
    DIRECTIONAL = "DIRECTIONAL"
    MATURE = "MATURE"
    REVERSAL_WATCH = "REVERSAL_WATCH"
    REVERSAL_LEG = "REVERSAL_LEG"
    COMPLETED = "COMPLETED"


class DirectionalEpisodeOrigin(StringEnum):
    NONE = "NONE"
    LEGACY_AUCTION_CONFIRMATION = "LEGACY_AUCTION_CONFIRMATION"
    REVERSAL_EVENT_HANDOFF = "REVERSAL_EVENT_HANDOFF"


class BalanceEpisodeState(StringEnum):
    NONE = "NONE"
    FORMING = "FORMING"
    PROBABLE = "PROBABLE"
    LOCKED = "LOCKED"
    ESCAPE_WATCH = "ESCAPE_WATCH"
    ACCEPTED_OUTSIDE = "ACCEPTED_OUTSIDE"
    FAILED_BACK_INSIDE = "FAILED_BACK_INSIDE"
    COMPLETED = "COMPLETED"


class EpisodeTransitionType(StringEnum):
    DIRECTIONAL_STARTED = "DIRECTIONAL_STARTED"
    DIRECTIONAL_MATURED = "DIRECTIONAL_MATURED"
    REVERSAL_WATCH_STARTED = "REVERSAL_WATCH_STARTED"
    DIRECTIONAL_REVERSAL_CONFIRMED = "DIRECTIONAL_REVERSAL_CONFIRMED"
    DIRECTIONAL_REVERSAL_LEG_STARTED = "DIRECTIONAL_REVERSAL_LEG_STARTED"
    DIRECTIONAL_REVERSAL_LEG_ESTABLISHED = "DIRECTIONAL_REVERSAL_LEG_ESTABLISHED"
    DIRECTIONAL_REVERSAL_LEG_FAILED = "DIRECTIONAL_REVERSAL_LEG_FAILED"
    DIRECTIONAL_TREND_RESTORED = "DIRECTIONAL_TREND_RESTORED"
    DIRECTIONAL_COMPLETED = "DIRECTIONAL_COMPLETED"
    BALANCE_FORMING_STARTED = "BALANCE_FORMING_STARTED"
    BALANCE_PROBABLE = "BALANCE_PROBABLE"
    BALANCE_LOCKED = "BALANCE_LOCKED"
    BALANCE_ESCAPE_STARTED = "BALANCE_ESCAPE_STARTED"
    BALANCE_ESCAPE_ACCEPTED = "BALANCE_ESCAPE_ACCEPTED"
    BALANCE_ESCAPE_FAILED = "BALANCE_ESCAPE_FAILED"
    BALANCE_COMPLETED = "BALANCE_COMPLETED"


class EpisodeObservation(ContractModel):
    """Objective input applied once to the previous persistent episode state."""

    symbol: str = Field(min_length=1)
    trading_day: date
    snapshot_time: datetime
    close: float = Field(gt=0.0)
    high: float = Field(gt=0.0)
    low: float = Field(gt=0.0)
    atr: float = Field(gt=0.0)

    auction_state: AuctionStateName
    directional_bias: DirectionalBias
    established_trend_side: DirectionalBias
    trend_direction: DirectionalBias
    current_leg_mature: bool
    extension_mature: bool

    exhaustion_active: bool
    exhausted_side: DirectionalBias
    rejection_observed: bool
    failed_extreme_observed: bool
    structural_failure_confirmed: bool
    failure_watch_active: bool

    trend_protection_level: Optional[float] = Field(default=None, gt=0.0)
    trend_protection_source: str = ""
    trend_protection_time: Optional[datetime] = None
    trend_protection_version: int = Field(default=0, ge=0)

    accepted_range_id: Optional[str] = None
    accepted_range_low: Optional[float] = Field(default=None, gt=0.0)
    accepted_range_high: Optional[float] = Field(default=None, gt=0.0)
    accepted_range_established_at: Optional[datetime] = None
    accepted_range_provisional: bool
    accepted_range_breakout_eligible: bool
    accepted_range_inside: bool
    # Relative close location within the accepted-range width. This is
    # intentionally unbounded: values below 0 are below the range and values
    # above 1 are above the range. `accepted_range_inside` separately records
    # tolerance-aware containment.
    accepted_range_position: Optional[float] = None
    accepted_range_outside_atr: Optional[float] = None
    range_width_atr: Optional[float] = Field(default=None, ge=0.0)
    directional_efficiency: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    overlap_ratio: Optional[float] = Field(default=None, ge=0.0, le=1.0)

    source_reason_codes: Tuple[str, ...] = ()

    @model_validator(mode="after")
    def _validate_observation(self) -> "EpisodeObservation":
        if self.trading_day != self.snapshot_time.date():
            raise ValueError("EpisodeObservation trading_day must match snapshot_time")
        if self.high < self.low:
            raise ValueError("EpisodeObservation high must be >= low")
        if self.high < max(self.close, self.low):
            raise ValueError("EpisodeObservation high cannot be below close")
        if self.low > min(self.close, self.high):
            raise ValueError("EpisodeObservation low cannot be above close")
        if (self.accepted_range_low is None) != (self.accepted_range_high is None):
            raise ValueError("Accepted range low/high must be supplied together")
        if self.accepted_range_low is not None and self.accepted_range_high is not None:
            if self.accepted_range_high <= self.accepted_range_low:
                raise ValueError("Accepted range high must exceed low")
        if self.accepted_range_inside and self.accepted_range_low is None:
            raise ValueError("accepted_range_inside requires accepted range geometry")
        if self.accepted_range_position is not None and self.accepted_range_low is None:
            raise ValueError("accepted_range_position requires accepted range geometry")
        if self.exhaustion_active:
            if self.exhausted_side not in (DirectionalBias.UP, DirectionalBias.DOWN):
                raise ValueError("Active exhaustion requires an exhausted side")
        return self


class EpisodeTransition(ContractModel):
    event_id: str = Field(min_length=1)
    event_type: EpisodeTransitionType
    episode_id: str = Field(min_length=1)
    symbol: str = Field(min_length=1)
    trading_day: date
    event_time: datetime
    direction: DirectionalBias = DirectionalBias.UNKNOWN
    reason_codes: Tuple[str, ...] = ()
    data: Dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_event(self) -> "EpisodeTransition":
        if self.trading_day != self.event_time.date():
            raise ValueError("EpisodeTransition trading_day must match event_time")
        return self


class DirectionalEpisodeProjection(ContractModel):
    episode_id: Optional[str] = None
    previous_state: DirectionalEpisodeState
    current_state: DirectionalEpisodeState
    direction: DirectionalBias
    origin_source: DirectionalEpisodeOrigin
    parent_episode_id: Optional[str] = None
    origin_event_id: Optional[str] = None
    started_at: Optional[datetime] = None
    state_started_at: Optional[datetime] = None
    state_age_bars: int = Field(ge=0)
    origin_price: Optional[float] = Field(default=None, gt=0.0)
    extreme_price: Optional[float] = Field(default=None, gt=0.0)
    extreme_time: Optional[datetime] = None
    protection_level: Optional[float] = Field(default=None, gt=0.0)
    protection_source: str = ""
    reversal_confirmation_level: Optional[float] = Field(default=None, gt=0.0)
    reversal_confirmation_source: str = ""
    reversal_confirmation_level_time: Optional[datetime] = None
    first_adverse_bar_time: Optional[datetime] = None
    first_adverse_bar_level: Optional[float] = Field(default=None, gt=0.0)
    first_adverse_bar_close: Optional[float] = Field(default=None, gt=0.0)
    rejection_seen: bool
    continuation_failure_seen: bool
    continuation_failure_time: Optional[datetime] = None
    reversal_confirmation_breach_closes: int = Field(ge=0)
    reversal_leg_progress_bars: int = Field(ge=0)
    reversal_leg_failure_closes: int = Field(ge=0)
    reversal_leg_progress_atr: float = Field(ge=0.0)
    reason_codes: Tuple[str, ...] = ()

    @model_validator(mode="after")
    def _validate_directional(self) -> "DirectionalEpisodeProjection":
        if self.current_state is DirectionalEpisodeState.NONE:
            if self.episode_id is not None:
                raise ValueError("Directional NONE cannot have episode_id")
            if self.origin_source is not DirectionalEpisodeOrigin.NONE:
                raise ValueError("Directional NONE requires origin_source NONE")
            if self.parent_episode_id is not None or self.origin_event_id is not None:
                raise ValueError("Directional NONE cannot retain origin linkage")
        else:
            if self.episode_id is None or self.started_at is None or self.state_started_at is None:
                raise ValueError("Active directional episode requires identity and timestamps")
            if self.direction not in (DirectionalBias.UP, DirectionalBias.DOWN):
                raise ValueError("Active directional episode requires UP or DOWN direction")
            if self.origin_source is DirectionalEpisodeOrigin.NONE:
                raise ValueError("Active directional episode requires an origin source")
            if self.origin_source is DirectionalEpisodeOrigin.REVERSAL_EVENT_HANDOFF:
                if self.parent_episode_id is None or self.origin_event_id is None:
                    raise ValueError("Reversal handoff requires parent episode and origin event")
            elif self.parent_episode_id is not None or self.origin_event_id is not None:
                raise ValueError("Legacy directional origin cannot carry handoff linkage")
        if (self.first_adverse_bar_time is None) != (self.first_adverse_bar_level is None):
            raise ValueError("First adverse bar time/level must be supplied together")
        if self.first_adverse_bar_level is None and self.first_adverse_bar_close is not None:
            raise ValueError("First adverse bar close requires adverse bar geometry")
        if self.first_adverse_bar_level is not None and self.first_adverse_bar_close is None:
            raise ValueError("First adverse bar geometry requires close")
        if self.continuation_failure_seen and self.continuation_failure_time is None:
            raise ValueError("Continuation failure requires a timestamp")
        if not self.continuation_failure_seen and self.continuation_failure_time is not None:
            raise ValueError("Continuation failure timestamp requires the stage")
        if self.reversal_confirmation_level is None:
            if self.reversal_confirmation_level_time is not None:
                raise ValueError("Reversal confirmation time requires a level")
            if self.reversal_confirmation_source:
                raise ValueError("Reversal confirmation source requires a level")
        elif self.reversal_confirmation_level_time is None:
            raise ValueError("Reversal confirmation level requires a timestamp")
        if self.current_state is DirectionalEpisodeState.REVERSAL_LEG:
            if self.origin_source is not DirectionalEpisodeOrigin.REVERSAL_EVENT_HANDOFF:
                raise ValueError("REVERSAL_LEG requires reversal-event handoff origin")
        return self


class BalanceEpisodeProjection(ContractModel):
    episode_id: Optional[str] = None
    previous_state: BalanceEpisodeState
    current_state: BalanceEpisodeState
    started_at: Optional[datetime] = None
    state_started_at: Optional[datetime] = None
    state_age_bars: int = Field(ge=0)
    range_id: Optional[str] = None
    candidate_low: Optional[float] = Field(default=None, gt=0.0)
    candidate_high: Optional[float] = Field(default=None, gt=0.0)
    source_range_ids: Tuple[str, ...] = ()
    candidate_merge_count: int = Field(ge=0)
    candidate_bar_expansion_count: int = Field(ge=0)
    candidate_last_valid_at: Optional[datetime] = None
    forming_invalid_bars: int = Field(ge=0)
    frozen_low: Optional[float] = Field(default=None, gt=0.0)
    frozen_high: Optional[float] = Field(default=None, gt=0.0)
    containment_bars: int = Field(ge=0)
    forming_bars_observed: int = Field(ge=0)
    marginal_excursion_bars: int = Field(ge=0)
    meaningful_escape_bars: int = Field(ge=0)
    containment_ratio: float = Field(ge=0.0, le=1.0)
    escape_direction: DirectionalBias
    outside_close_count: int = Field(ge=0)
    reentry_close_count: int = Field(ge=0)
    reason_codes: Tuple[str, ...] = ()

    @model_validator(mode="after")
    def _validate_balance(self) -> "BalanceEpisodeProjection":
        if self.current_state is BalanceEpisodeState.NONE:
            if self.episode_id is not None:
                raise ValueError("Balance NONE cannot have episode_id")
            return self
        if self.episode_id is None or self.started_at is None or self.state_started_at is None:
            raise ValueError("Active balance episode requires identity and timestamps")
        if self.current_state in {
            BalanceEpisodeState.FORMING,
            BalanceEpisodeState.PROBABLE,
        }:
            if self.candidate_low is None or self.candidate_high is None:
                raise ValueError("FORMING/PROBABLE balance requires candidate geometry")
        elif self.current_state in {
            BalanceEpisodeState.LOCKED,
            BalanceEpisodeState.ESCAPE_WATCH,
            BalanceEpisodeState.ACCEPTED_OUTSIDE,
            BalanceEpisodeState.FAILED_BACK_INSIDE,
        }:
            if self.range_id is None or self.frozen_low is None or self.frozen_high is None:
                raise ValueError("Locked/resolving balance requires frozen geometry")
        if self.candidate_low is not None and self.candidate_high is not None:
            if self.candidate_high <= self.candidate_low:
                raise ValueError("Balance candidate_high must exceed candidate_low")
        if self.frozen_low is not None and self.frozen_high is not None:
            if self.frozen_high <= self.frozen_low:
                raise ValueError("Balance frozen_high must exceed frozen_low")
        if self.forming_bars_observed == 0:
            if self.containment_bars or self.marginal_excursion_bars or self.meaningful_escape_bars:
                raise ValueError("Balance evidence counts require observed forming bars")
        else:
            expected = self.containment_bars / self.forming_bars_observed
            if abs(self.containment_ratio - expected) > 1e-9:
                raise ValueError("Balance containment_ratio must match evidence counts")
        return self


class EpisodeEvaluation(ContractModel):
    symbol: str = Field(min_length=1)
    trading_day: date
    snapshot_time: datetime
    directional: DirectionalEpisodeProjection
    balance: BalanceEpisodeProjection
    events: Tuple[EpisodeTransition, ...] = ()
    structural_event_families: Tuple[SetupFamily, ...] = ()
    permitted_setup_families: Tuple[SetupFamily, ...] = ()
    blocked_setup_families: Tuple[SetupFamily, ...] = ()
    diagnostics: Dict[str, Any] = Field(default_factory=dict)
    config_version: str = Field(min_length=1)

    @model_validator(mode="after")
    def _validate_evaluation(self) -> "EpisodeEvaluation":
        if self.trading_day != self.snapshot_time.date():
            raise ValueError("EpisodeEvaluation trading_day must match snapshot_time")
        for event in self.events:
            if event.symbol != self.symbol or event.event_time != self.snapshot_time:
                raise ValueError("Episode events must align with evaluation")
        structural = set(self.structural_event_families)
        permitted = set(self.permitted_setup_families)
        blocked = set(self.blocked_setup_families)
        if not permitted.issubset(structural):
            raise ValueError("Permitted setup families must originate from structural events")
        if permitted.intersection(blocked):
            raise ValueError("A setup family cannot be both permitted and blocked")
        return self


__all__ = [
    "DirectionalEpisodeState",
    "BalanceEpisodeState",
    "EpisodeTransitionType",
    "EpisodeObservation",
    "EpisodeTransition",
    "DirectionalEpisodeProjection",
    "BalanceEpisodeProjection",
    "EpisodeEvaluation",
]
