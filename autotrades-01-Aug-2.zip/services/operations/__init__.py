"""One-shot operational services."""
